<?php

namespace App\Http\Controllers;

use App\Mail\ContactForm;
use http\Client\Curl\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class HomeController extends Controller
{
    public function index()
    {
        return view('index');
    }

    public function overView()
    {
        return view('overView');
    }

    public function whatWeDo()
    {
        return view('whatWeDo');
    }

    public function contactUs()
    {
        return view('contactUs');
    }

    public function sendMail( Request $request)
    {

        Mail::to($request->email)->send(new ContactForm());
//        dd($request->all());
        // Check for empty fields
//        dd('fdf');
//        if(empty($request->name)      ||
//            empty($request->email)     ||
//            empty($request->phone)     ||
//            empty($request->message)   ||
//            !filter_var($request->email,FILTER_VALIDATE_EMAIL))
//        {
//            echo "No arguments Provided!";
//            return false;
//        }
//
//        $name = strip_tags(htmlspecialchars($request->name));
//        $email_address = strip_tags(htmlspecialchars($request->email));
//        $phone = strip_tags(htmlspecialchars($request->phone));
//        $message = strip_tags(htmlspecialchars($request->message));
//        // Create the email and send the message
//        $to = 'mido.b333@gmail.com'; // Add your email address inbetween the '' replacing yourname@yourdomain.com - This is where the form will send a message to.
//        $email_subject = "Website Contact Form:  $name";
//        $email_body = "You have received a new message from your website contact form.\n\n"."Here are the details:\n\nName: $name\n\nEmail: $email_address\n\nPhone: $phone\n\nMessage:\n$message";
//        $headers = "From: noreply@yourdomain.com\n"; // This is the email address the generated message will be from. We recommend using something like noreply@yourdomain.com.
//        $headers .= "Reply-To: $email_address";
//        $bo = mail($to,$email_subject,$email_body,$headers);
//        dd($bo);
//        return 'sent';
    }

    public function provisionAdnBonded()
    {
        return view('subPages.provisionBonded');
    }

    public function technicalStores()
    {
        return view('subPages.technicalStores');
    }

    public function logisticServices()
    {
        return view('subPages.logisticServices');
    }
}
