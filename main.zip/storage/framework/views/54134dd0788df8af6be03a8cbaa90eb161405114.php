<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <?php echo $__env->make('includes.headerFiles', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <title><?php echo $__env->yieldContent('title'); ?></title>

</head>

<body>

<!-- Navigation -->
<?php echo $__env->make('includes.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page Header -->
<?php echo $__env->make('includes.pageHeader', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!-- Main Content -->
<?php echo $__env->yieldContent('content'); ?>

<!-- Footer -->
<footer>
    <div class="container">
        
       
        <div class="row">
            <div class="col-lg-8 col-md-10 mx-auto">
                <p class="text-center">Powered By <a href="https://www.facebook.com/mohamedelsayed300" class="text-decoration-none" style="color: #0085a1">Alaraby</a> </p>
            </div>
        </div>
    </div>
</footer>

<?php echo $__env->make('includes.footerFiles', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>

</html>
